// src/pages/SignupPage.jsx
import { useState, useRef } from "react";
import { useNavigate } from "react-router-dom";
import PrimaryButton from "../../components/button/PrimaryButton.jsx";
import OutlineButton from "../../components/button/OutlineButton.jsx";

const API_BASE = import.meta.env.VITE_API_BASE_URL ?? "http://localhost:8080";

function SignupPage() {
  const navigate = useNavigate();
  const fileInputRef = useRef(null);

  const [form, setForm] = useState({
    email: "",
    loginId: "",
    name: "",
    password: "",
    passwordCheck: "",
    nickname: "",
    birthYear: "",
    gender: "",
    phone: "",
    profileImageUrl: "",
  });

  const [submitting, setSubmitting] = useState(false);
  const [uploadingProfile, setUploadingProfile] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleClickUpload = () => {
    fileInputRef.current?.click();
  };

  const handleProfileChange = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // TODO: 실제 S3 업로드 API에 맞게 수정
    setUploadingProfile(true);
    try {
      // 일단 프리뷰만
      const url = URL.createObjectURL(file);
      setForm((prev) => ({ ...prev, profileImageUrl: url }));
    } finally {
      setUploadingProfile(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!form.email || !form.loginId || !form.password || !form.passwordCheck) {
      alert("필수 정보를 입력해주세요.");
      return;
    }
    if (form.password !== form.passwordCheck) {
      alert("비밀번호와 비밀번호 확인이 일치하지 않습니다.");
      return;
    }

    setSubmitting(true);
    try {
      const res = await fetch(`${API_BASE}/api/auth/signup`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: form.email,
          loginId: form.loginId,
          name: form.name,
          password: form.password,
          nickname: form.nickname,
          birthYear: form.birthYear,
          gender: form.gender,
          phone: form.phone,
          // profileImageKey: ... // 실제 업로드 적용시 백엔드 스펙에 맞게
        }),
      });

      if (res.ok) {
        alert("회원가입이 완료되었습니다. 로그인 페이지로 이동합니다.");
        navigate("/login", { replace: true });
      } else {
        const text = await res.text();
        console.error(text);
        alert("회원가입 중 오류가 발생했습니다.");
      }
    } catch (err) {
      console.error(err);
      alert("서버와 통신할 수 없습니다.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <main className="min-h-[calc(100vh-88px)] flex items-center justify-center px-4 py-12 bg-secondary-light">
      <div className="max-w-[1100px] w-full bg-paper rounded-card shadow-card overflow-hidden flex flex-col md:flex-row">
        {/* Left */}
        <section className="flex-[0.8] bg-primary-light px-10 py-12 flex flex-col justify-center gap-3">
          <div className="w-[120px] h-[120px] rounded-full bg-paper flex items-center justify-center text-[64px] mb-4 shadow-card">
            👻
          </div>
          <h2 className="text-[24px] font-extrabold text-primary-dark tracking-[0.1em]">
            ㅍ ㅅ ㅍ
          </h2>
          <p className="mt-2 text-[14px] leading-relaxed text-text-black">
            당신 주변의 팝업 스토어를
            <br />
            더 빠르고 쉽게 만나보세요.
          </p>
          <p className="signup-left-text small text-[13px] text-text-sub">
            회원가입 후 예약, 위시리스트, 채팅 등
            <br />
            다양한 기능을 이용해보세요.
          </p>
        </section>

        {/* Right */}
        <section className="flex-[1.2] px-8 md:px-14 py-10 bg-paper">
          <div className="mb-6">
            <h1 className="text-[22px] font-bold text-text-black mb-2">
              회원가입
            </h1>
            <p className="text-[13px] text-text-sub">
              기본 정보를 입력하고, 팝스팝의 모든 기능을 이용해보세요.
            </p>
          </div>

          {/* 사진 업로드 영역 */}
          <div className="rounded-[12px] bg-[#f8f8fc] px-[18px] py-[16px] mb-6">
            <p className="m-0 text-[13px] font-semibold text-text-black mb-1">
              프로필 사진 (선택)
            </p>
            <p className="m-0 text-[13px] text-text-sub mb-3">
              나중에 마이페이지에서도 변경할 수 있어요.
            </p>

            <div className="flex items-center gap-4">
              {form.profileImageUrl && (
                <img
                  src={form.profileImageUrl}
                  alt="프로필 미리보기"
                  className="w-[56px] h-[56px] rounded-full object-cover border border-secondary"
                />
              )}

              <OutlineButton
                type="button"
                onClick={handleClickUpload}
                disabled={uploadingProfile}
              >
                {uploadingProfile ? "업로드 중..." : "사진 업로드"}
              </OutlineButton>
            </div>

            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={handleProfileChange}
            />
          </div>

          {/* 폼 */}
          <form className="flex flex-col gap-5" onSubmit={handleSubmit}>
            {/* 2열 영역 */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <label className="flex flex-col gap-1.5 text-[13px] text-text-sub">
                이메일
                <input
                  type="email"
                  name="email"
                  className="w-full px-3 py-2.5 rounded-input border border-secondary text-[14px] outline-none focus:border-primary focus:ring-1 focus:ring-primary/20"
                  placeholder="example@mail.com"
                  value={form.email}
                  onChange={handleChange}
                  disabled={submitting}
                />
              </label>

              <label className="flex flex-col gap-1.5 text-[13px] text-text-sub">
                아이디
                <input
                  type="text"
                  name="loginId"
                  className="w-full px-3 py-2.5 rounded-input border border-secondary text-[14px] outline-none focus:border-primary focus:ring-1 focus:ring-primary/20"
                  placeholder="아이디 입력"
                  value={form.loginId}
                  onChange={handleChange}
                  disabled={submitting}
                />
              </label>

              <label className="flex flex-col gap-1.5 text-[13px] text-text-sub">
                이름
                <input
                  type="text"
                  name="name"
                  className="w-full px-3 py-2.5 rounded-input border border-secondary text-[14px] outline-none focus:border-primary focus:ring-1 focus:ring-primary/20"
                  placeholder="이름 입력"
                  value={form.name}
                  onChange={handleChange}
                  disabled={submitting}
                />
              </label>

              <label className="flex flex-col gap-1.5 text-[13px] text-text-sub">
                닉네임
                <input
                  type="text"
                  name="nickname"
                  className="w-full px-3 py-2.5 rounded-input border border-secondary text-[14px] outline-none focus:border-primary focus:ring-1 focus:ring-primary/20"
                  placeholder="닉네임 입력"
                  value={form.nickname}
                  onChange={handleChange}
                  disabled={submitting}
                />
              </label>

              <label className="flex flex-col gap-1.5 text-[13px] text-text-sub">
                출생년도
                <input
                  type="number"
                  name="birthYear"
                  className="w-full px-3 py-2.5 rounded-input border border-secondary text-[14px] outline-none focus:border-primary focus:ring-1 focus:ring-primary/20"
                  placeholder="예: 1995"
                  value={form.birthYear}
                  onChange={handleChange}
                  disabled={submitting}
                />
              </label>

              <label className="flex flex-col gap-1.5 text-[13px] text-text-sub">
                성별
                <select
                  name="gender"
                  className="w-full px-3 py-2.5 rounded-input border border-secondary text-[14px] outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 bg-paper"
                  value={form.gender}
                  onChange={handleChange}
                  disabled={submitting}
                >
                  <option value="">선택</option>
                  <option value="M">남성</option>
                  <option value="F">여성</option>
                </select>
              </label>
            </div>

            {/* 비밀번호 / 연락처 */}
            <label className="flex flex-col gap-1.5 text-[13px] text-text-sub">
              비밀번호
              <input
                type="password"
                name="password"
                className="w-full px-3 py-2.5 rounded-input border border-secondary text-[14px] outline-none focus:border-primary focus:ring-1 focus:ring-primary/20"
                placeholder="8~20자, 영문/숫자/특수문자 포함"
                value={form.password}
                onChange={handleChange}
                disabled={submitting}
              />
            </label>

            <label className="flex flex-col gap-1.5 text-[13px] text-text-sub">
              비밀번호 확인
              <input
                type="password"
                name="passwordCheck"
                className="w-full px-3 py-2.5 rounded-input border border-secondary text-[14px] outline-none focus:border-primary focus:ring-1 focus:ring-primary/20"
                placeholder="비밀번호 재입력"
                value={form.passwordCheck}
                onChange={handleChange}
                disabled={submitting}
              />
            </label>

            <label className="flex flex-col gap-1.5 text-[13px] text-text-sub">
              전화번호
              <input
                type="tel"
                name="phone"
                className="w-full px-3 py-2.5 rounded-input border border-secondary text-[14px] outline-none focus:border-primary focus:ring-1 focus:ring-primary/20"
                placeholder="010-0000-0000"
                value={form.phone}
                onChange={handleChange}
                disabled={submitting}
              />
            </label>

            {/* 버튼 영역 */}
            <div className="mt-2 flex justify-end gap-2">
              <OutlineButton
                type="button"
                onClick={() => navigate("/login")}
                disabled={submitting}
              >
                취소
              </OutlineButton>
              <PrimaryButton
                type="submit"
                size="lg"
                loading={submitting}
              >
                {submitting ? "가입 중..." : "회원가입"}
              </PrimaryButton>
            </div>
          </form>
        </section>
      </div>
    </main>
  );
}

export default SignupPage;
