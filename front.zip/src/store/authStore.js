// src/store/authStore.js
import { create } from "zustand";
import { loginApi, logoutApi, fetchMeApi } from "../api/authApi";

export const useAuthStore = create((set, get) => ({
  user: null,          // 현재 로그인한 유저 정보
  loading: false,
  initialized: false,  // fetchMe 한 번 했는지 여부
  error: null,

  // 🔐 로그인
  login: async ({ loginId, password }) => {
    set({ loading: true, error: null });
    try {
      // 1) 로그인 -> 쿠키 세팅
      await loginApi({ loginId, password });

      // 2) 내 정보 가져오기
      const me = await fetchMeApi();

      set({
        user: me,
        loading: false,
        initialized: true,
      });
    } catch (err) {
      console.error("login error:", err);
      set({ loading: false, error: err });
      throw err;
    }
  },

  // 🚪 로그아웃
  logout: async () => {
    set({ loading: true, error: null });
    try {
      await logoutApi();
      set({ user: null, loading: false });
    } catch (err) {
      console.error("logout error:", err);
      set({ loading: false, error: err });
      throw err;
    }
  },

  // 앱 시작 시 내 정보 불러오기
  fetchMe: async () => {
    if (get().initialized) return;
    set({ loading: true, error: null });

    try {
      const me = await fetchMeApi();
      set({
        user: me,
        loading: false,
        initialized: true,
      });
    } catch (err) {
      // 401 등 → 로그인 안 된 상태
      console.warn("fetchMe error or not logged in:", err?.response?.status);
      set({
        user: null,
        loading: false,
        initialized: true,
      });
    }
  },
}));
