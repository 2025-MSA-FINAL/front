// src/App.jsx
import { Routes, Route } from "react-router-dom";
import Navbar from "./components/NavBar.jsx";

import LoginPage from "./pages/auth/LoginPage.jsx";
import MainPage from "./pages/MainPage.jsx";
import MyPage from "./pages/user/MyPage.jsx";

function App() {
  return (
    <div className="min-h-screen bg-secondary-light text-text-black">
      {/* 항상 NavBar 표시 */}
      <Navbar />

      <Routes>
        {/* 임시 메인 페이지 */}
        <Route path="/" element={<MainPage />} />

        {/* 로그인 페이지 */}
        <Route path="/login" element={<LoginPage />} />

        {/* 임시 마이페이지 */}
        <Route path="/mypage" element={<MyPage />} />

        {/* TODO: 추후 다른 페이지들 추가 */}
      </Routes>
    </div>
  );
}

export default App;
